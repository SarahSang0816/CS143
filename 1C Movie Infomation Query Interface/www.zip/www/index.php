<!DOCTYPE html>
<html>

<frameset rows="30%,70%" frameborder="0" border="0">
	<frame name="header" src="./php/header.php">
	<frame name="main" id="main-content" src="./php/content.php">
</frameset>

</html>