jQuery(document).ready(function() {
	jQuery('#submit').on("click", function(e) {
		var searchText = jQuery("#search").val();

		e.preventDefault();

		$.ajax({
			url: "./search.php", 
			type:"GET",
			data:{term:searchText},
			dataType:"html",
			success: function(result) {
				$("#content", window.parent.frames["main"].document.body).html(result);
			},
			error: function(xhr,status,error) {
				alert("ajax error: " + error.responseText + "     " + status);
			}
		});
	});
});