<?php require_once('others.php'); ?>
<html>
<body>
<head>
    <link rel="stylesheet" type="text/css" href="../css/addInfo.css">
  <title>Movie Info</title>
</head>

<body class="body">
    <div id="content" align="left" class="content">

<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="GET">

<h1>
Add new movie:
</h1>

Title: <input type = "text" name = "title"> <br>
Company: <input type="text" name="company"> <br>
Year: <input type="text" name="year"> <br>
MPAA Rating: <SELECT NAME="rating">
<option value = 'NR'>NR</option>
<option value = 'G'>G</option>
<option value = 'PG'>PG</option>
<option value = 'PG-13'>PG-13</option>
<option value = 'R'>R</option>
<option value = 'NC-17'>NC-17</option>
</SELECT>
<br/>
Genre:
<input type = "checkbox" name = "genre[]" value = "Action">Action
<input type = "checkbox" name = "genre[]" value = "Adult">Adult
<input type = "checkbox" name = "genre[]" value = "Adventure">Adventure
<input type = "checkbox" name = "genre[]" value = "Animation">Animation
<input type = "checkbox" name = "genre[]" value = "Comedy">Comedy
<input type = "checkbox" name = "genre[]" value = "Crime">Crime
<input type = "checkbox" name = "genre[]" value = "Documentary">Documentary
<input type = "checkbox" name = "genre[]" value = "Drama">Drama
<input type = "checkbox" name = "genre[]" value = "Family">Family
<input type = "checkbox" name = "genre[]" value = "Fantasy">Fantasy
<input type = "checkbox" name = "genre[]" value = "Horror">Horror
<input type = "checkbox" name = "genre[]" value = "Musical">Musical
<input type = "checkbox" name = "genre[]" value = "Mystery">Mystery
<input type = "checkbox" name = "genre[]" value = "Romance">Romance
<input type = "checkbox" name = "genre[]" value = "Sci-Fi">Sci-Fi
<input type = "checkbox" name = "genre[]" value = "Short">Short
<input type = "checkbox" name = "genre[]" value = "Thriller">Thriller
<input type = "checkbox" name = "genre[]" value = "War">War
<input type = "checkbox" name = "genre[]" value = "Western">Western
<br><br>
<input type="submit" value="Add it">

</form>
</div>
<?php
if($_GET['rating']){
	if (!$_GET['title'])
    {echo '<h3 style="margin-left:50px;"><b>Please enter movie title.</b></h3>';}
    else
    {
        $db_connection = connect();

      if(!$db_connection) {
          $errmsg = mysql_error($db_connection);
          echo "Connection failed: $errmsg <br />";
          exit(1);
       }
      $q = 'UPDATE MaxMovieID SET id = id+1';
      query($q, $db_connection);
      $q = 'SELECT id FROM MaxMovieID';
      $rs= query($q, $db_connection);
      $row = mysql_fetch_row($rs);
      $maxid = $row[0];
      $title = $_GET['title'];
      $company = $_GET['company'];
      $year = $_GET['year']? $_GET['year']:'0';
      $rating = $_GET['rating'];
      $genre = $_GET['genre'];

      $q = "INSERT INTO Movie VALUES($maxid, '$title', $year, '$rating', '$company')";
      query($q, $db_connection);
      echo '<h3 style="margin-left:50px;"><b>Add success!</b></h3>';
      $n = count($genre);
      for ($i=0 ; $i < $n ; $i++ ) { 
        $q = "INSERT INTO MovieGenre VALUES($maxid, '$genre[$i]')";
        query($q, $db_connection);
      }
      mysql_close($db_connection);
    }
}
?>

</body>
</html>

