<?php require_once('others.php'); ?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../css/addInfo.css">
    <title>Movie Info</title>
</head>

<body class="body">
    <div id="content" align="left" class="content">
<h1>
	Add actor to movie:
</h1>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="GET">
	Keyword for movie: <input type = "text" name = "mkeyword"><br>
	Keyword for actor: <input type = "text" name = "akeyword"><br>
	<input type = "submit" value = "search"><br>

	<?php
	$mkeyword = $_GET['mkeyword'];
	$akeyword = $_GET['akeyword'];
	echo "Select a movie: <select name = 'movie'>";

	$db_connection = connect();
	if(!$db_connection){
		$errmsg = mysql_error($db_connection);
		echo "Connection failed:" .  $errmsg . "<br/>";
		exit(1);
	}

	$q = "SELECT id, CONCAT(title, '(', year, ')') AS title FROM Movie WHERE title LIKE '%$mkeyword%'";
	$rs = mysql_query($q, $db_connection);

	while($row = mysql_fetch_row($rs)){
		if($row[0] == $_GET['movie'])
			echo "<option value = \"$row[0]\" selected>$row[1]</option>";
		else
			echo "<option value = \"$row[0]\">$row[1]</option>";
	}
	echo "</select><br>";
	
	echo "Select an actor: <select name = 'actor'>";
	
	$q = "SELECT id, CONCAT(first, ' ', last, '(', dob, ')') AS name FROM Actor WHERE first LIKE '%$akeyword%' OR last LIKE '%$akeyword'";
	$rs = mysql_query($q, $db_connection);

	while($row = mysql_fetch_row($rs)){
		if($row[0] == $_GET['actor'])
			echo "<option value = \"$row[0]\" selected>$row[1]</option>";
		else
			echo "<option value = \"$row[0]\">$row[1]</option>";
	}
	?>
</select><br>
Enter a role: <input type = "text" name = "role"><br>
	<input type = "submit" name = "submit" value = "Add it">
</form>
</div>
<?php
	if($_GET['movie'] && $_GET['actor'] && $_GET['submit']){
		$mid = $_GET['movie'];
		$aid = $_GET['actor'];
		$role = $_GET['role'];
		$q = "INSERT INTO MovieActor(mid, aid, role) VALUES ($mid, $aid, \"$role\")";
		mysql_query($q, $db_connection);
		echo '<h3 style="margin-left:50px;"><b>Add success!</b></h3>';
	}
	mysql_close($db_connection);
?>


</body>
</html>