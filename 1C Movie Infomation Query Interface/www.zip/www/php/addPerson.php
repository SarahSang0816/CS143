<?php require_once('others.php'); ?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../css/addInfo.css">
	<title>Movie Info</title>
</head>

<body class="body">
    <div id="content" align="left" class="content">

<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="GET">
<h1>
Add new actor/director:
</h1>
Identity:
<input type="radio" name="identity" value="Actor" checked>Actor
<input type="radio" name="identity" value="Director">Director <br>
First Name: <input type="text" name="first"> <br>
Last Name: <input type="text" name="last"> <br>

Sex:
<input type = "radio" name = "sex" value = "Male" checked>Male
<input type = "radio" name = "sex" value = "Female">Female <br>
Date of Birth: <input type = "date" name = "dob"> <br>
Date of Death: <input type = "date" name = "dod"> (leave blank if alive now) <br>

<input type="submit" value="Add it">

</form>
</div>
<?php
if($_GET['identity']){
	if(!$_GET['first'])
		echo '<h3 style="margin-left:50px;"><b>Please enter first name.</b></h3>';
    else if(!$_GET['last'])
    	echo '<h3 style="margin-left:50px;"><b>Please enter last name.</b></h3>';
    else if(!$_GET['dob'])
    	echo '<h3 style="margin-left:50px;"><b>Please enter date of birth.</b></h3>';
    else{
    	$db_connection = connect();
    	if(!$db_connection){
    		$errmsg = mysql_error($db_connection);
			echo "Connection failed:" .  $errmsg . "<br/>";
			exit(1);
    	}
    	$q_update = 'UPDATE MaxPersonID SET id = id + 1';
    	$rs = query($q_update, $db_connection);
    	if (!$rs) {
			echo 'Could not run query: ' . mysql_error();
    		exit;
		}
		$q_id = 'SELECT id FROM MaxPersonID';
		$rs = query($q_id, $db_connection);
		$row = mysql_fetch_row($rs);
		$max_id = $row[0];

		$first = $_GET['first'];
		$last = $_GET['last'];
		$dob = $_GET['dob'];
		$dod = $_GET['dod'];
		$dod = $dod ? "'$dod'" : 'NULL';
		$sex = $_GET['sex'];

		if($_GET['identity'] == 'Actor'){
			$q = "INSERT INTO Actor(id, last, first, sex, dob, dod) VALUES ($max_id, '$last', '$first', '$sex', '$dob', $dod)";
		}
		else{
			$q = "INSERT INTO Director(id, last, first, dob, dod) VALUES ($max_id, '$last', '$first', '$dob', $dod)";
		}
		query($q, $db_connection);
		echo '<h3 style="margin-left:50px;"><b>Add success!</b></h3>';
		mysql_close($db_connection);
    }







}






?>

</body>
</html>

