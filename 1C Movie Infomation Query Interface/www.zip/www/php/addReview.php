<?php require_once('others.php'); ?>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../css/addInfo.css">
    <title>Movie Info</title>
</head>

<body class="body">
    <div id="content" align="left" class="content">
<h1>
	Add comments to a movie:
</h1>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="GET">
	Select a movie: <select name = "movie">
	<?php
	$db_connection = connect();
	if(!$db_connection){
		$errmsg = mysql_error($db_connection);
		echo "Connection failed:" .  $errmsg . "<br/>";
		exit(1);
	}

	$q = "SELECT id, CONCAT(title, '(', year, ')') AS title FROM Movie";
	$rs = mysql_query($q, $db_connection);

	while($row = mysql_fetch_row($rs)){
		if($row[0] == $_GET['movie'])
			echo "<option value = \"$row[0]\" selected>$row[1]</option>";
		else
			echo "<option value = \"$row[0]\">$row[1]</option>";
	}
	echo "</select><br>";
	?>
	Your name: <input type = "text" name = "name"><br>
	Rating: <select name = 'rating'>
	<?php
		for($i = 0; $i <= 5; $i++){
			echo "<option value = \"$i\">$i</option>";
		}
	?>
</select>
<br>
Add comment: <br>
<textarea name = "comment" rows = "8" cols = "80"></textarea><br>
<input type = "submit" value = "Add it">

</form>
</div>
<?php
	if($_GET['movie'] && $_GET['rating']){
		$mid = $_GET['movie'];
		$name = $_GET['name'];
		$rating = $_GET['rating'];
		$comment = $_GET['comment'];
		$q = "INSERT INTO Review(name, time, mid, rating, comment) VALUES (\"$name\", CURRENT_TIMESTAMP, $mid, $rating, \"$rating\")";
		mysql_query($q, $db_connection);
		echo '<h3 style="margin-left:50px;"><b>Add success!</b></h3>';
	}
mysql_close($db_connection);

?>

</body>
</html>
