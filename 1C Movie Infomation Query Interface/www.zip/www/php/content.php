<!DOCTYPE html>
<html>

<head>
	<link rel="stylesheet" type="text/css" href="../css/content.css">
</head>

<body class="body">
	<div id="content" align="center" class="content">
		<h1>Happy Halloween!</h1>
		<img src="../css/content_background.png" class="image" alt="Happy Halloween!">
	</div>
</body>

</html>