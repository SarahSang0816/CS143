<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="../css/header.css">
    <script src="../jquery/jquery-1.11.3.min.js"></script>
    <script src="../jquery/action.js"></script>
    <title>Movie Info</title>
</head>

<body id="header">
    <div class="tabs" align="center">
        <h1 class="title">Movie Info</h1>

        <nav class="menu">
            <ul class="tab-links">
                <li><a href="./content.php" target="main">Home</a></li>

                <li><a href="./addPerson.php" target="main">Add New Actor/Director</a></li>

                <li>
                    <a>Add Movie Related Info<span class="arrow">&#9660;</span></a>

                    <ul class="sub-menu">
                        <li><a href="./addMovie.php" target="main">Add Movie</a></li>
                        <li><a href="./addMovieActor.php" target="main">Add Movie Actor</a></li>
                        <li><a href="./addMovieDirector.php" target="main">Add Movie Director</a></li>
                        <li><a href="./addReview.php" target="main">Add Movie Review</a></li>
                    </ul>
                </li>

                <li>
                    <form id="search-form" class="search-box" method="get">
                        <input id="search" type="text" class="input-field" placeholder="Type Query here">
                        <button id="submit" class="search-button">Search</button>
                    </form>
                </li>
            </ul>
        </nav>
    </div>
</body>

</html>