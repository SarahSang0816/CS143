<?php
/* 	establishing a coonection with MYSQL
	connect to the MySQL database system on the machine "localhost"
	and specify a particular database CS143 we'll be accessing
*/
function connect() {
	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);
	return $db_connection;
}

function query($query, $db_connection)
{
	$result = mysql_query($query, $db_connection);
	return $result;
}


function clear($db_connection)
{
	mysql_close($db_connection);
}

?>
