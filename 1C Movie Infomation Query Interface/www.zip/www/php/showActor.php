<!DOCTYPE html>
<?php require_once('others.php'); ?>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="../css/addInfo.css">
    <title>Movie Info</title>
</head>

<body class="body">
    <div id="content" align="left" class="content">
        <h1>Actor Information</h1>

        <?php
            $id = $_GET['aid'] ? $_GET['aid'] : '0';
            $q = "SELECT last, first, sex, dob, dod
                FROM Actor
                WHERE id = $id
                LIMIT 1";

            $db_connection = connect();

            if(!$db_connection) {
                $errmsg = mysql_error($db_connection);
                echo '<h3 style="margin-left:50px;"><b>Failed to connect to database: $errmsg</b></h3>';
                exit(1);
            }

            $rs = mysql_query($q, $db_connection);
            $row = mysql_fetch_row($rs);
                    echo "<li>Name: $row[1] $row[0]</li>";
                    echo "<li>Sex: $row[2]</li>";
                    echo "<li>Date of Birth: $row[3]</li>";
                if (isset($row[4])) {
                    echo "<li>Date of Death: $row[4]</li>";            
                } else {
                	echo "<li>Date of Death: --Still Alive--</li>";
                }

            echo "<br>";
            echo "<h2>Roles in Movies</h2>";
            $q = "SELECT mid, role FROM MovieActor WHERE aid=$id";
            $rs = mysql_query($q, $db_connection);
            echo '<table class="table" border=1 cellpadding=8>';
            echo "<tr class=\"table-header\"><td><b>role</b></td><td><b>movie</b></td></tr>";
            while($row = mysql_fetch_row($rs)) {
                $query = "SELECT title, year FROM Movie WHERE id='$row[0]' LIMIT 1";
                $movie = mysql_query($query, $db_connection);
                $tuple = mysql_fetch_row($movie);
                echo "<tr class=\"table-row\">";
                echo "<td>$row[1]</td>";
                echo "<td><a href=\"showMovie.php?mid={$row[0]}\">$tuple[0]</a>($tuple[1])</td>";
                echo "</tr>";
            }
            echo "</table>";

            clear($db_connection);
        ?>
    </div>
</body>

</html>
