<!DOCTYPE html>
<?php require_once('others.php'); ?>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="../css/addInfo.css">
    <title>Movie Info</title>
</head>

<body class="body">
    <div id="content" align="left" class="content">
        <h1>Movie Information</h1>

        <?php
            $id = $_GET['mid'] ? $_GET['mid'] : '0';

            $db_connection = connect();

            if(!$db_connection) {
                $errmsg = mysql_error($db_connection);
                echo '<h3 style="margin-left:50px;"><b>Failed to connect to database: $errmsg</b></h3>';
                exit(1);
            }

            $q = "SELECT title, year, company, rating FROM Movie WHERE id = $id LIMIT 1";

            $director_q = "SELECT Director.first, Director.last FROM Director,MovieDirector 
                            WHERE MovieDirector.did = Director.id AND MovieDirector.mid = $id";

            $cast_q = "SELECT Actor.id, Actor.first, Actor.last, MovieActor.role FROM Actor, MovieActor
                            WHERE MovieActor.mid = $id AND Actor.id = MovieActor.aid";

            $genre_q = "SELECT DISTINCT(genre) FROM MovieGenre WHERE mid = $id";

            $avg_rating_q = "SELECT AVG(rating), count(*) FROM Review WHERE mid = $id";

            $comments_q = "SELECT name, rating, comment, time FROM Review WHERE mid = $id ORDER BY time DESC";

            $rs = mysql_query($q, $db_connection);
            $row = mysql_fetch_row($rs);
            echo "<li>Title: $row[0] ($row[1])</li>";
            echo "<li>Producer: $row[2]</li>";
            echo "<li>MPAA Rating: $row[3]</li>";
            echo "<li>Director: ";
            $rs = mysql_query($director_q, $db_connection);
            $isfirst = true;
            while ($row = mysql_fetch_row($rs)) {
                if ($isfirst) {
                    echo "$row[0] $row[1]";
                    $isfirst = false;
                } else {
                    echo ", $row[0] $row[1]";
                }
            }
            echo "</li>";
            echo "<li>Genre: ";
            $rs = mysql_query($genre_q, $db_connection);
            $isfirst = true;
            while ($row = mysql_fetch_row($rs)) {
                if ($isfirst) {
                    echo "$row[0]";
                    $isfirst = false;
                } else {
                    echo ", $row[0]";
                }
            }

            echo "<br>";
            echo "<h2>CAST</h2>";
            $rs = mysql_query($cast_q, $db_connection);
            echo '<table class="table" border=1 cellpadding=8>';
            echo "<tr class=\"table-header\"><td>Actor</td><td>Role</td></tr>";
            while ($row = mysql_fetch_row($rs)) {
                echo "<tr class=\"table-row\"><td><a href=\"showActor.php?aid={$row[0]}\">$row[1] $row[2]</a></td>";
                echo "<td>$row[3]</td></tr>";
            }          
            echo "</table>";

            echo "<br>";
            echo "<h2>Reviews</h2>";
            $rs = mysql_query($avg_rating_q, $db_connection);
            $row = mysql_fetch_row($rs);
            echo "Average Rating: $row[0]/5 by $row[1] review(s)<br>";
            echo "<a style=\"margin-top:6px; margin-bottom:6px; font-family:'Ek Mukta'; color:#424242; font-size:18px;\" href=\"./addMovieReview.php?movie=$id\" target=\"main\"><b>Add review to this movie!</b></a><br><br>";
            echo "All Comments:<br><br>";
            $rs = mysql_query($comments_q, $db_connection);
            while ($row = mysql_fetch_row($rs)) {
                echo "&nbsp;&nbsp;&nbsp;&nbsp;On $row[3], $row[0] rates $row[1] points: $row[2]<br>";
            }

            mysql_close($db_connection);
        ?>
    </div>
</body>
</html>